
	PRESERVE8
	AREA functions, CODE, READONLY
	EXPORT asctoint
		
asctoint

	MOV r0, #10
	