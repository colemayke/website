
	PRESERVE8
	AREA MyCode, CODE, READONLY
	EXPORT asmmain
	
	

asmmain
	import myfprint
	import myintprint
	import my_getchar
	import my_putchar
		
	MOV r8, #0 
	MOV r0, #0 
	MOV r1, #0 
	MOV r2, #0 
	MOV r3, #0 
	MOV r4, #0 
	MOV r5, #0 
	MOV r6, #0 
	MOV r7, #0 
	MOV r9, #0
	MOV r10, #0 	
	
	//MOV r9, #0
	
	LDR r0,=start
	BL myfprint
	
	
	LDR r7,=argument
	
	
	BAL getinput
	
	
getinput

	MOV r0, #0x0
	BL my_getchar
	
	MOV r1, r0
	
	MOV r0, r0
	BL my_putchar
	
	MOV r0, r1
	
	CMP r0, #0x39
	BGT makeDes
	
	CMP r0, #0x30
	BLT makeDes
	
	SUB r0, r0, #0x30
	
	
	CMP r9, #1
	MOVEQ r4, #16
	MOVNE r4, #1
	MUL r4, r5, r4

	
	ADD r5, r4, r0
	
	//MOV r4, r5, LSL#3
	//ADD r4, r4, r5, LSL#1
	//ADD r5, r4, r0
	
	MOV r9, #1
	
	BAL getinput
	
	
makeDes

	MOV r0, r1 

	CMP r0, #0xD
	BEQ newline	
	
	CMP r0, #0x2A
	BEQ DoMult
			
	CMP r0, #0x2B
	BEQ DoAdd
	
	CMP r0, #0x2D
	BEQ DoSub
	
	CMP r0, #0x2F
	BEQ DoDiv
	
	CMP r0, #0x3D
	BEQ DoShow
	
	B error
	
	
DoSub
	CMP r6, #1
	BLT getinput
	
	LDR r1, [r7, #-4]
	LDR r2, [r7, #-8]
	
	SUB r1, r2, r1
	STR r1, [r7, #-8]
	SUB r6, r6, #1
	SUB r7, r7, #4
	
	BAL getinput
	
DoMult

	CMP r6, #1
	BLT getinput
	
	LDR r1, [r7, #-4]
	LDR r2, [r7, #-8]
	
	MUL r1, r1, r2

	STR r1, [r7, #-8]
	SUB r6, r6, #1
	SUB r7, r7, #4
	
	BAL getinput

	
DoDiv

	CMP r6, #1
	BLT getinput
	
	LDR r1, [r7, #-4]
	LDR r2, [r7, #-8]
	
	UDIV r1, r2, r1
	STR r1, [r7, #-8]
	SUB r6, r6, #1
	SUB r7, r7, #4
	
	BAL getinput
	
DoAdd


	CMP r6, #1
	BLT error
	
	LDR r1, [r7, #-4]
	LDR r2, [r7, #-8]
	
	ADD r1, r2, r1
	STR r1, [r7, #-8]
	SUB r6, r6, #1
	SUB r7, r7, #4
	
	
	BAL getinput
	
DoShow

	MOV r0, #0xA
	BL my_putchar
	MOV r0, #0xD
	BL my_putchar
	
	
	LDR r4, [r7, #-4]
	
	LSR r4, #12
	AND r4, #0x0F
	MOV r0, r4
	BL myintprint	
	
	LDR r4, [r7, #-4]
	
	LSR r4, #8
	AND r4, #0x0F
	MOV r0, r4
	BL myintprint
	

	LDR r4, [r7, #-4]
	
	LSR r4, #4
	AND r4, #0x0F
	MOV r0, r4
	BL myintprint
	
	LDR r4, [r7, #-4]
	
	AND r4, #0x0F
	MOV r0, r4
	BL myintprint 
	
	BAL getinput  
	

error 
	
	BAL getinput
	
newline

	MOV r0, #0xA
	BL my_putchar
	MOV r0, #0xD
	BL my_putchar


	CMP r5, #0
	BEQ getinput
	
	STR r5, [r7], #4 
	ADD r6, r6, #1
	MOV r5, #0x0
	
	MOV r9, #0x0
	
	BAL getinput

stop B stop

	ALIGN
	AREA MyData, DATA, READWRITE

argument SPACE 64
start DCB "Type the RPN expression with Enter after each argument and operator", 0

	END
		