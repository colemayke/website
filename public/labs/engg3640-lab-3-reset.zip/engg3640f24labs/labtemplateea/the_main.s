
	PRESERVE8
	AREA MyCode, CODE, READONLY
	EXPORT asmmain
	
asmmain
	import myfprint
	MOV r4, #2555
	MOV r2, #7
	MOV r8, #1
	mov r5, #2555
	mov r6, #45
	mov r7, #21
	
	
	BAL mainloop
	


mainloop
	
	mov r4, #2555
	mov r5, #2555
	mov r6, #45
	mov r7, #21
	
	cmp r8, #1
	BEQ fp1
	
	cmp r8, #2
	BEQ fp2
	
	cmp r8, #3
	BEQ fp3
	
	cmp r8, #4
	BEQ fp4
	
	cmp r8, #5
	BEQ fp5
	
	cmp r8, #6
	BEQ fp6
	
	cmp r8, #7
	BEQ fp7
	
	
	SUBS r2, r2, #1
	cmp r2, #0
	
	BNE Bigloop
	BEQ asmmain	
	
	
Bigloop 

	mov r9, r9
	mov r9, r9
	mov r9, r9
	sub r4, r4, #1
	cmp r4, #0

	BNE Bigloop
	BEQ smaloop

smaloop

	mov r9, r9
	mov r9, r9
	mov r9, r9
	mov r4, #2555
	sub r5, r5, #1
	cmp r5, #0
	BNE Bigloop
	BEQ smallloop

smallloop

	mov r9, r9
	mov r9, r9
	mov r9, r9
	mov r5, #2555
	sub r6, r6, #1
	cmp r6, #0
	BNE smallloop
	BEQ smallerloop
	
smallerloop

	mov r9, r9
	mov r9, r9
	mov r9, r9
	mov r6, #45
	sub r7, r7, #1
	cmp r7, #0
	BNE smaloop
	BEQ mainloop
	
	
fp1
		
	LDR r0, =print1
	BL myfprint
	add r8, r8, #1
	BAL Bigloop
	
fp2
		
	LDR r0, =print2
	BL myfprint
	add r8, r8, #1
	BAL Bigloop
	
fp3
		
	LDR r0, =print3
	BL myfprint
	add r8, r8, #1
	BAL Bigloop
	
fp4
		
	LDR r0, =print4
	BL myfprint
	add r8, r8, #1
	BAL Bigloop
	
fp5
		
	LDR r0, =print5
	BL myfprint
	add r8, r8, #1
	BAL Bigloop
	
fp6
		
	LDR r0, =print6
	BL myfprint
	add r8, r8, #1
	BAL Bigloop
	
fp7
		
	LDR r0, =print7
	BL myfprint
	add r8, r8, #1
	mov r8, #2
	BAL Bigloop
	
	
		
stop B stop

	ALIGN
	AREA MyData, DATA, READWRITE
srcstr DCB "made small loop",0
dststr DCB "Seconds",0
mainstr DCB "In main",0
bigloopstr DCB "In Bigloop",0
mainloopstr DCB "In mainloop",0
start DCB "Back to start",0
prints DCB "made it to pritning",0
printe DCB "made it to end of pritning",0
print1 DCB "Start of Program! Time 0s",0
print2 DCB "10 seconds have passed! Time 10s",0
print3 DCB "10 seconds have passed! Time 20s",0
print4 DCB "10 seconds have passed! Time 30s",0
print5 DCB "10 seconds have passed! Time 40s",0
print6 DCB "10 seconds have passed! Time 50s",0
print7 DCB "10 seconds have passed! Next will loop back to 10. Time 60s",0

	END
		
		