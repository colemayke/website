
	PRESERVE8
	AREA MyCode, CODE, READONLY
	EXPORT asmmain
	import fprint
	IMPORT check
	
low_power_control_status_reg EQU 0x40040000  //CSR
low_power_control_prescale_reg EQU 0x40040004   //PSR 
low_power_control_compare_reg EQU 0x40040008   //CMR
low_power_control_counter_reg EQU 0x4004000C   //CNR
nvic_starter EQU 0xE000E100
irq_vector EQU 0x00200000
system_clock_gate_control_reg EQU 0x40048038
alien_base EQU 0x42000000
timer_flag EQU 0x4280001C ;error here during demo as well, 4200001C, meant not clearing flag properly

		

asmmain	

	LDR r2, =system_clock_gate_control_reg
	LDR r0, [r2] 
	ORR r0, r0, #0x00000001
	STR r0, [r2] 

	MOV r1, #0x00000040
	LDR r2, =low_power_control_status_reg
	STR r1, [r2] 
	ADD r2, #0x4 
	
	MOV r1, #0x00000005
	STR r1, [r2]
	ADD r2, #0x4 
	
	MOV r1, #0x00002710
	STR r1, [r2]
	SUB r2, #0x8
	
	MOV r1, #0x00000001
	LDR r0, [r2]
	ORR r0, r0, r1
	STR r0, [r2]	
	
NVIC

	MOV r1, #0x00200000
	LDR r2, =nvic_starter
	STR r1,[r2,#0x8]
	
loop B loop
	EXPORT asm_low_power_timer_interrupt_request	
		

LPTMR0_IRQHandler EQU asm_low_power_timer_interrupt_request+1;
	EXPORT LPTMR0_IRQHandler;
	
asm_low_power_timer_interrupt_request
	PUSH {lr}
	LDR r2, =timer_flag
	MOV r1, #0x01
	STR r1, [r2]
	
	LDR r1, =irqcounter
	LDRB r0, [r1]
	ADD r0, r0, #1
	
	BL fprint
	
	LDR r1, =irqcounter ;WHERER THE FUCKING ERROR WAS 
	LDRB r0, [r1]
	ADD r0, r0, #1
	STRB r0, [r1]
	POP {pc}


	ALIGN
	AREA MyData, DATA, READWRITE

irqcounter DCD 0x00

	END
		