.\objects\lab_2_main.o: lab_2_main.s
