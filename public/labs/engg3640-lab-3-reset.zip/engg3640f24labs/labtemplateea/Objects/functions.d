.\objects\functions.o: functions.s
