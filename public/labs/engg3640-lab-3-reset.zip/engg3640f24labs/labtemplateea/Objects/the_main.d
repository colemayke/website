.\objects\the_main.o: the_main.s
